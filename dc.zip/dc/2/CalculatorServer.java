## CalculatorServer.java
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class CalculatorServer {
    public static void main(String[] args) {
        try {
            ICalculator calculator = new Calculator();
            LocateRegistry.createRegistry(1099); // Start RMI registry
            Naming.rebind("CalculatorService", calculator); // Bind service
            System.out.println("Calculator Server is ready.");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}

## On the client machine:
## 1. Compile ICalculator.java and CalculatorClient.java
## 2. Run CalculatorClient using the command java CalculatorClient serverHostname