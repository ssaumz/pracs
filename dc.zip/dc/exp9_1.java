import java.io.*;
import java.net.*;
import java.util.Scanner;

public class SharedMemoryClient {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 5000;

    public static void main(String[] args) {
        try (
                Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                Scanner scanner = new Scanner(System.in)
        ) {
            System.out.println("Connected to SharedMemoryServer. Type 'exit' to quit.");

            while (true) {
                System.out.print("Enter Command (get/set/exit): ");
                String command = scanner.nextLine().trim();

                if (command.equalsIgnoreCase("exit")) {
                    out.println("exit");
                    System.out.println("Disconnecting...");
                    break;
                } else if (command.equalsIgnoreCase("get")) {
                    out.println("get");
                    System.out.println(in.readLine());
                } else if (command.equalsIgnoreCase("set")) {
                    System.out.print("Enter Value: ");
                    String value = scanner.nextLine().trim();
                    out.println("set " + value);
                    System.out.println(in.readLine());
                } else {
                    out.println(command);
                    System.out.println(in.readLine());
                }
            }
        } catch (UnknownHostException e) {
            System.err.println("Unknown host: " + SERVER_HOST);
            System.err.println(e.getMessage());
        } catch (IOException e) {
            System.err.println("Could not connect to server");
            System.err.println(e.getMessage());
        }
    }
}
