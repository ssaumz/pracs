## Hello.idl
module HelloApp {
    interface Hello {
        string sayHello();
    };
};


## HelloServer.java
import HelloApp.*;
import org.omg.CORBA.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.PortableServer.*;
import org.omg.PortableServer.POA;

class HelloImpl extends HelloPOA {
    private ORB orb;

    public void setORB(ORB orb) {
        this.orb = orb;
    }

    @Override
    public String sayHello() {
        return "Hello, World from CORBA!";
    }
}

public class HelloServer {
    public static void main(String args[]) {
        try {
            // Initialize ORB
            ORB orb = ORB.init(args, null);
            POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootpoa.the_POAManager().activate();

            // Create servant and register it with the ORB
            HelloImpl helloImpl = new HelloImpl();
            helloImpl.setORB(orb);

            org.omg.CORBA.Object ref = rootpoa.servant_to_reference(helloImpl);
            Hello helloRef = HelloHelper.narrow(ref);

            // Get Naming Context
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

            // Bind object reference in Naming Service
            NameComponent path[] = ncRef.to_name("Hello");
            ncRef.rebind(path, helloRef);

            System.out.println("HelloServer ready and waiting...");

            // Wait for client invocations
            orb.run();
        } catch (Exception e) {
            System.out.println("ERROR: " + e);
            e.printStackTrace();
        }
    }
}