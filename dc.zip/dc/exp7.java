import java.util.Scanner;

public class exp7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] process_time = new int[10];

        System.out.println("*** Ricart Agrawala Algorithm ***");
	System.out.println("DC Experiment No. 07\nName: Saumya Poojari");
	System.out.println("-------------------------------------------");
        System.out.print("Enter the number of processes: ");
        int n = Integer.parseInt(scanner.nextLine());

        System.out.println("Now enter their timestamps...");


        for (int i = 0; i < n; i++) {
            System.out.print("Enter the timestamp for Process [" + i + "]: ");
            process_time[i] = Integer.parseInt(scanner.nextLine());
        }

        System.out.print("Enter 2 process who wants a shared resource:  ");
        String[] processIds = scanner.nextLine().split(" ");
        int p1 = Integer.parseInt(processIds[0]);
        int p2 = Integer.parseInt(processIds[1]);

        for (int i = 0; i < n; i++) {
            System.out.println("Process [" + p1 + "] sends timestamp " + process_time[p1] + " to Process [" + i +"]" );
        }

        for (int i = 0; i < n; i++) {
            System.out.println("Process [" + p2 + "] sends timestamp " + process_time[p2] + " to Process [" + i +"]" );
        }

        int p = (process_time[p1] < process_time[p2]) ? p1 : p2;
        int t = Math.min(process_time[p1], process_time[p2]);

        System.out.println("Process [" + p + "] has the lowest timestamp = " + t);
        for (int i = 0; i<n; i++){
            if (i==p) continue;
            else System.out.println("Process [" + i + "] sent OK! message to Process [" + p +"]" );
        }
        System.out.println("Hence Process [" + p + "] is accessing the shared resource, once it is done using it,");
        System.out.println("Process [" + (p1 == p? p2:p1) + "] can use it");

        scanner.close();
    }
}