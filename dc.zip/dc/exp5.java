import java.util.*;

public class exp5 {

    static int max1(int a, int b) {
        return Math.max(a, b);
    }

    static void display(int e1, int e2, int[] p1, int[] p2) {
        System.out.println("\nThe time stamps of events in P1:");
        for (int i = 0; i < e1; i++) {
            System.out.print(p1[i] + " ");
        }

        System.out.println("\nThe time stamps of events in P2:");
        for (int i = 0; i < e2; i++) {
            System.out.print(p2[i] + " ");
        }
    }

    static void lamportLogicalClock(int e1, int e2, int[][] m) {
        int[] p1 = new int[e1];
        int[] p2 = new int[e2];

        // Initialize timestamps
        for (int i = 0; i < e1; i++) {
            p1[i] = i + 1;
        }
        for (int i = 0; i < e2; i++) {
            p2[i] = i + 1;
        }

        // Display matrix
        System.out.print("\n\t");
        for (int i = 0; i < e2; i++) {
            System.out.print("e2" + (i + 1) + "\t");
        }

        for (int i = 0; i < e1; i++) {
            System.out.print("\ne1" + (i + 1) + "\t");
            for (int j = 0; j < e2; j++) {
                System.out.print(m[i][j] + "\t");
            }
        }

        // Update timestamps based on message matrix
        for (int i = 0; i < e1; i++) {
            for (int j = 0; j < e2; j++) {

                if (m[i][j] == 1) {
                    p2[j] = max1(p2[j], p1[i] + 1);
                    for (int k = j + 1; k < e2; k++) {
                        p2[k] = p2[k - 1] + 1;
                    }
                }

                if (m[i][j] == -1) {
                    p1[i] = max1(p1[i], p2[j] + 1);
                    for (int k = i + 1; k < e1; k++) {
                        p1[k] = p1[k - 1] + 1;
                    }
                }
            }
        }

        // Display final timestamps
        display(e1, e2, p1, p2);
    }

    public static void main(String[] args) {
        int e1 = 5, e2 = 3;
        int[][] m = new int[5][3];

        System.out.println("DC Experiment No. 05\nName: Saumya Poojari");
	System.out.println("-----------------------------------");

        // Initialize message matrix
        m[0][0] = 0;  m[0][1] = 0;  m[0][2] = 0;
        m[1][0] = 0;  m[1][1] = 0;  m[1][2] = 1;
        m[2][0] = 0;  m[2][1] = 0;  m[2][2] = 0;
        m[3][0] = 0;  m[3][1] = 0;  m[3][2] = 0;
        m[4][0] = 0;  m[4][1] = -1; m[4][2] = 0;

        // Execute Lamport clock algorithm
        lamportLogicalClock(e1, e2, m);
    }
}