import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class exp6 {
    public static void main(String[] args){
        System.out.println("\n*** ELECTION ALGORITHM: Bully Algorithm ***\n");
	System.out.println("DC Experiment No. 06\nName: Saumya Poojari");
	System.out.println("-----------------------------------");
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of Processes: ");
        int n = sc.nextInt();
        ArrayList<Boolean> process = new ArrayList<>();
        int prev_req = -1;
        for(int i=0; i<n; i++) {
            process.add(new Random().nextBoolean());
        }
        process.set(n-1, false);
        System.out.println("\nCoordinator Process: "+n+"\nCoordinator Process Now Dead: " + n);
        int req = new Random().nextInt(n-1);
        System.out.println(process);
        System.out.println(req+1);
        while (req < n-1 && prev_req != req){
            System.out.println("\n\nRequesting Process: "+(req+1));
            for(int j = req+1; j<n; j++){
                System.out.println("\n\tProcess["+(req+1)+"]====Election====>Process["+(j+1)+"]");
            }
            System.out.println();
            prev_req = req;
            req = BullyAlgo(req, n, process);
        }
        System.out.println("\n\nElected Coordinator Process: "+(req+1)+"\nSending Message to All other Process...");
        for(int k=0; k<req; k++){
            System.out.println("\n\tProcess["+(req+1)+"]====Coordinator====>Process["+(k+1)+"]");
        }
        System.out.println("\nAll Messages Sent!!!");
    }

    public static int BullyAlgo(int req, int n, ArrayList<Boolean> processes){
        for(int m=req+1; m<n; m++){
            if(processes.get(m)){
                System.out.println("\n\tReply from Process["+(m+1)+"]: OK");
                req=m;
                break;
            }
        }
        return req;
    }
}