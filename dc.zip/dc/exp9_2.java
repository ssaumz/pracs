import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class SharedMemoryServer {
    private static int sharedVariable = 50; // Initial value of the shared variable
    private static final Object lock = new Object(); // Lock for synchronization
    private static final int PORT = 5000;

    public static void main(String[] args) {
        // Create a thread pool to handle multiple client connections
        ExecutorService executor = Executors.newCachedThreadPool();

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("SharedMemoryServer started on port " + PORT + "...");

            while (true) {
                try {
                    // Wait for a client to connect
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("New client connected: " + clientSocket.getInetAddress().getHostAddress());

                    // Create a new handler for this client and submit it to the thread pool
                    ClientHandler handler = new ClientHandler(clientSocket);
                    executor.submit(handler);
                } catch (IOException e) {
                    System.err.println("Error accepting client connection: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Could not listen on port " + PORT);
            System.err.println(e.getMessage());
        } finally {
            executor.shutdown();
        }
    }

    // Inner class to handle client communication
    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try (
                    BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                    PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
            ) {
                String inputLine;

                // Process client commands until the client disconnects
                while ((inputLine = in.readLine()) != null) {
                    String[] tokens = inputLine.split(" ", 2);
                    String command = tokens[0].toLowerCase();

                    switch (command) {
                        case "get":
                            synchronized (lock) {
                                out.println("Accessed Shared Variable: " + sharedVariable);
                            }
                            break;

                        case "set":
                            if (tokens.length > 1) {
                                try {
                                    int newValue = Integer.parseInt(tokens[1]);
                                    synchronized (lock) {
                                        sharedVariable = newValue;
                                        out.println("Updated Shared Variable: " + sharedVariable);
                                    }
                                } catch (NumberFormatException e) {
                                    out.println("Error: Value must be an integer");
                                }
                            } else {
                                out.println("Error: No value provided for set command");
                            }
                            break;

                        case "exit":
                            System.out.println("Client disconnecting: " + clientSocket.getInetAddress().getHostAddress());
                            return;

                        default:
                            out.println("Invalid Command");
                            break;
                    }
                }
            } catch (IOException e) {
                System.err.println("Error handling client: " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                    System.out.println("Client disconnected: " + clientSocket.getInetAddress().getHostAddress());
                } catch (IOException e) {
                    System.err.println("Error closing connection: " + e.getMessage());
                }
            }
        }
    }
}