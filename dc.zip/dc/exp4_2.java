import java.io.*;
import java.net.*;

public class exp4_2 {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 12345;
    private static PrintWriter out;
    private static BufferedReader in;

    public static void main(String[] args) throws IOException {
        Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);


        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));


        System.out.print("Enter your name: ");
        String name = userInput.readLine();
        out.println(name);


        Thread readThread = new Thread(new ReadMessages(in));
        readThread.start();


        String message;
        while ((message = userInput.readLine()) != null) {
            out.println(message);
        }

        socket.close();
    }


    private static class ReadMessages implements Runnable {
        private BufferedReader in;

        public ReadMessages(BufferedReader in) {
            this.in = in;
        }

        @Override
        public void run() {
            try {
                String message;
                while ((message = in.readLine()) != null) {
                    System.out.println(message);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
